=== FG Joomla to WordPress Premium K2 module ===
Contributors: Frédéric GILLES
Plugin Uri: http://www.fredericgilles.net/fg-joomla-to-wordpress/
Tags: joomla, wordpress, migrator, converter, import, k2
Requires at least: 3.3
Tested up to: WP 3.9
Stable tag: 1.9.1
License: GPLv2

A plugin to migrate K2 content from Joomla to WordPress
Needs the plugin «FG Joomla to WordPress Premium» to work

== Description ==

This is the K2 module. It works only if the plugin FG Joomla to WordPress Premium is already installed.
It has been tested with **Joomla version 1.5** and **Wordpress 3.9** on huge databases (72 000+ posts). It is compatible with multisite installations.

Major features include:

* migrates K2 items
* migrates K2 categories
* migrates K2 tags
* migrates K2 comments
* migrates K2 images
* migrates K2 attachments
* migrates K2 custom fields
* migrates K2 authors
* migrates K2 videos
* migrates K2 images galleries
* migrates K2 navigation menus
* option to keep the K2 items IDs

== Installation ==

1.  Prerequesite: Buy and install the plugin «FG Joomla to WordPress Premium»
2.  Extract plugin zip file and load up to your wp-content/plugin directory
3.  Activate Plugin in the Admin => Plugins Menu
4.  Run the importer in Tools > Import > Joomla (FG)

== Translations ==
* English (default)
* French (fr_FR)
* Spanish (es_ES)
* German (de_DE)
* Russian (ru_RU)
* Polish (pl_PL)
* other can be translated

== Changelog ==

= 1.9.1 =
New: Refactor the menus import
Tested with WordPress 3.9

= 1.9.0 =
New: Option to keep the K2 items IDs
Tested with WordPress 3.8.1

= 1.8.0 =
New: Full refactoring of the URL redirect

= 1.7.3 =
Fixed: The trashed items were imported
Fixed: The trashed categories were imported
Fixed: Notice: Undefined property: fgj2wp_k2::$attachments_count

= 1.7.2 =
Fixed: Rewrite rules not deactivated after plugin deactivation

= 1.7.1 =
Fixed: Display the number of comments
Fixed: The attachments with spaces were not imported

= 1.7.0 =
New: Import K2 navigation menus

= 1.6.4 =
New translation: Spanish (thanks to Bradis García L.)
Fixed: Fatal error and undefined index notice fixes

= 1.6.3 =
New translation: Polish (Thanks to Łukasz Z.)

= 1.6.2 =
Optimize the Joomla connection

= 1.6.1 =
Fixed: Notice when $_POST['k2_images'] was not defined
Tested with WordPress 3.6

= 1.6.0 =
New: Import images captions
Tested with WordPress 3.5.2

= 1.5.2 =
Fixed: Replaces the publication date by the creation date as Joomla uses the creation date for sorting articles

= 1.5.1 =
New: Option to not use the first post image as the featured image

= 1.5.0 =
Migrates K2 images galleries
New translation: Russian (Thanks to Julia N.)

= 1.4.2 =
Fixed: Duplicates in multiselect fields
Fixed: Ability to import iframed videos even for non super-admins. We can use the plugin http://wordpress.org/extend/plugins/iframe/ to view the iframes.

= 1.4.1 =
Fixed: the K2 options were not saved when testing the connection

= 1.4.0 =
Migrates the K2 videos
Fixed: multiselect extra fields now get the value and not the index
Add hooks for getting views

= 1.3.0 =
URL redirect for the K2 items (SEO)

= 1.2.2 =
Fix the "modify internal links" for K2 items when not using SEF

= 1.2.1 =
Tested with WordPress 3.5.1
Modifies the K2 ID post meta
Fix the "modify internal links" for K2 items

= 1.2.0 =
Option to import the K2 images in the content or just as featured images
Ability to import K2 items as WordPress pages

= 1.1.0 =
Migrates the K2 authors

= 1.0.1 =
Tested with WordPress 3.5
Ability to migrate non K2 databases even when the K2 module is activated

= 1.0.0 =
Structured as a module of «FG Joomla to WordPress Premium»
