<?php
/**
 * FG Joomla to WordPress K2 Module
 * URL Rewriting module
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

add_filter('fgj2wpp_rewrite_rules', array('fgj2wp_k2_urlrewriting', 'add_rules'));
add_action( 'plugins_loaded', 'fgj2wp_k2_url_rewriting', 25 );

if ( !function_exists( 'fgj2wp_k2_url_rewriting' ) ) {
	function fgj2wp_k2_url_rewriting() {
		$urlrewriting = new fgj2wp_k2_urlrewriting();
	}
}

if ( !class_exists('fgj2wp_k2_urlrewriting', false) ) {
	class fgj2wp_k2_urlrewriting {

		private static $rewrite_rules = array(
			array( 'rule' => '^.*item/(\d+)-',		'meta_key' => '_fgj2wp_old_k2_id'),
		);
		
		/**
		 * Sets up the plugin
		 *
		 */
		public function __construct() {
			$premium_options = get_option('fgj2wpp_options');
			if ( isset($premium_options['url_redirect']) && !empty($premium_options['url_redirect']) ) {
				add_filter('fgj2wpp_rewrite_rules', array(&$this, 'add_rules'));

				// for Joomla non SEF URLs
				add_action('fgj2wpp_pre_404_redirect', array(&$this, 'pre_404_redirect'));
			}
		}
		
		/**
		 * Add rewrite rules
		 *
		 * @param array $rewrite_rules Custom rewrite rules
		 * @return array Custom rewrite rules
		 */
		public function add_rules($rewrite_rules) {
			$rewrite_rules = array_merge(self::$rewrite_rules, $rewrite_rules);
			return $rewrite_rules;
		}
		
		/**
		 * Try to redirect the Joomla non SEF URLs
		 */
		public function pre_404_redirect() {
			// Joomla configured without SEF URLs: view=item&id=xxx
			$view = get_query_var('view');
			if ( $view == 'item' ) {
				if ( preg_match('/(\d+)/', get_query_var('id'), $matches) ) {
					$old_id = $matches[1];
					fgj2wpp_urlrewriting::redirect('_fgj2wp_old_k2_id', $old_id);
				}
			}
		}
	}
}
?>
