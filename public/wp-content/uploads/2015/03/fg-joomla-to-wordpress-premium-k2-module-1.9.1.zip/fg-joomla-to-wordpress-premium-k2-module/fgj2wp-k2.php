<?php
/**
 * Plugin Name: FG Joomla to WordPress Premium K2 module
 * Depends:		FG Joomla to WordPress Premium
 * Plugin Uri:  http://www.fredericgilles.net/fg-joomla-to-wordpress/
 * Description: A plugin to migrate K2 content from Joomla to WordPress
 * 				Needs the plugin «FG Joomla to WordPress Premium» to work
 * Version:     1.9.1
 * Author:      Frédéric GILLES
 */

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

require_once 'fgj2wp-k2-url-rewriting.php';

add_action( 'admin_init', 'fgj2wp_k2_test_requirements' );

if ( !function_exists( 'fgj2wp_k2_test_requirements' ) ) {
	function fgj2wp_k2_test_requirements() {
		$fgj2wp_k2_requirements = new fgj2wp_k2_requirements();
	}
}

if ( !class_exists('fgj2wp_k2_requirements', false) ) {
	class fgj2wp_k2_requirements {
		private $parent_plugin = 'fg-joomla-to-wordpress-premium/fg-joomla-to-wordpress-premium.php';
		private $required_premium_version = '1.30.0';

		public function __construct() {
			load_plugin_textdomain( 'fgj2wp_k2', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
			if ( !is_plugin_active($this->parent_plugin) ) {
				add_action( 'admin_notices', array($this, 'fgj2wp_k2_error') );
			} else {
				$plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $this->parent_plugin);
				if ( !$plugin_data or version_compare($plugin_data['Version'], $this->required_premium_version, '<') ) {
					add_action( 'admin_notices', array($this, 'fgj2wp_k2_version_error') );
				}
			}
		}
		
		/**
		 * Print an error message if the Premium plugin is not activated
		 */
		function fgj2wp_k2_error() {
			echo '<div class="error"><p>[fgj2wp_k2] '.__('The K2 module needs the «FG Joomla to WordPress Premium» plugin to work. Please install and activate <strong>FG Joomla to WordPress Premium</strong>.', 'fgj2wp_k2').'<br /><a href="http://www.fredericgilles.net/fg-joomla-to-wordpress/" target="_blank">http://www.fredericgilles.net/fg-joomla-to-wordpress/</a></p></div>';
		}
		
		/**
		 * Print an error message if the Premium plugin is not at the required version
		 */
		function fgj2wp_k2_version_error() {
			printf('<div class="error"><p>[fgj2wp_k2] '.__('The K2 module needs at least the <strong>version %s</strong> of the «FG Joomla to WordPress Premium» plugin to work. Please install and activate <strong>FG Joomla to WordPress Premium</strong> at least the <strong>version %s</strong>.', 'fgj2wp_k2').'<br /><a href="http://www.fredericgilles.net/fg-joomla-to-wordpress/" target="_blank">http://www.fredericgilles.net/fg-joomla-to-wordpress/</a></p></div>', $this->required_premium_version, $this->required_premium_version);
		}
	}
}

if ( !defined('WP_LOAD_IMPORTERS') )
	return;

add_action( 'plugins_loaded', 'fgj2wp_k2_load', 25 );

if ( !function_exists( 'fgj2wp_k2_load' ) ) {
	function fgj2wp_k2_load() {
		if ( !defined('FGJ2WPP_LOADED') )
			return;

		load_plugin_textdomain( 'fgj2wp_k2', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		
		global $fgj2wpp;
		$fgj2wp_k2 = new fgj2wp_k2($fgj2wpp);
	}
}

if ( !class_exists('fgj2wp_k2', false) ) {
	class fgj2wp_k2 {
		
		public $items_count = 0;
		public $comments_count = 0;
		public $media_count = 0;
		public $tags_count = 0;
		protected $k2_options = array();
		
		/**
		 * Sets up the plugin
		 *
		 */
		public function __construct($plugin) {
			
			$this->plugin = $plugin;
			
			add_action( 'fgj2wp_post_empty_database', array (&$this, 'reset_last_k2_item_id'), 10, 1 );
			add_action( 'fgj2wp_post_save_plugin_options', array (&$this, 'save_k2_options') );
			add_filter( 'fgj2wp_get_categories', array (&$this, 'get_categories'), 10, 1 );
			add_action( 'fgj2wp_pre_import_posts', array (&$this, 'remove_keep_joomla_id'));
			add_action( 'fgj2wp_pre_import_posts', array (&$this, 'set_posts_autoincrement'), 11);
			add_action( 'fgj2wp_post_import_posts', array (&$this, 'import_items') );
			add_filter( 'fgj2wp_k2_pre_insert_post', array (&$this, 'add_import_id'), 10, 2);
			add_filter( 'fgj2wp_k2_pre_insert_post', array (&$this, 'pre_insert_post'), 10, 2 );
			add_action( 'fgj2wp_k2_post_insert_post', array (&$this, 'post_insert_post'), 10, 2 );
			add_action( 'fgj2wp_k2_post_insert_post', array (&$this, 'import_comments'), 10, 2 );
			add_filter( 'fgj2wp_pre_get_joomla_id_in_link', array (&$this, 'get_k2_item_id_in_link'), 10, 2 );
			add_filter( 'fgj2wp_get_menus_add_extra_criteria', array (&$this, 'add_menus_extra_criteria'), 10, 1 );
			add_filter( 'fgj2wp_get_menu_item', array (&$this, 'get_menu_item'), 10, 3 );
			
			add_action( 'fgj2wp_import_notices', array (&$this, 'display_items_count') );
			add_action( 'fgj2wp_import_notices', array (&$this, 'display_comments_count') );
			add_action( 'fgj2wp_import_notices', array (&$this, 'display_media_count') );
			add_action( 'fgj2wp_import_notices', array (&$this, 'display_tags_count') );
			
			add_filter( 'fgj2wp_pre_display_admin_page', array (&$this, 'process_admin_page'), 11, 1 );
			add_action( 'fgj2wp_post_display_behavior_options', array (&$this, 'display_k2_options') );
			
			// Default values
			$this->k2_options = array(
				'k2_images'				=> 'in_content',
				'keep_k2_id'			=> false,
			);
			$options = get_option('fgj2wpk2_options');
			if ( is_array($options) ) {
				$this->k2_options = array_merge($this->k2_options, $options);
			}
		}

		/**
		 * Reset the stored last K2 item id during emptying the database
		 * 
		 */
		public function reset_last_k2_item_id($action) {
			update_option('fgj2wp_last_k2_item_id', 0);
		}

		/**
		 * Get K2 categories
		 *
		 * @param array $categories array of Categories
		 * @return array of Categories
		 */
		public function get_categories($categories) {
			global $joomla_db;

			try {
				$prefix = $this->plugin->plugin_options['prefix'];
				
				$sql = "
					SELECT c.name AS title, CONCAT('ck', c.id, '-', c.alias) AS name, c.description, CONCAT('ck', p.id, '-', p.alias) AS parent
					FROM ${prefix}k2_categories c
					LEFT JOIN ${prefix}k2_categories AS p ON p.id = c.parent
					WHERE c.trash = 0
				";
				
				$query = $joomla_db->query($sql);
				if ( is_object($query) ) {
					foreach ( $query as $row ) {
						$categories[] = $row;
					}
				}
				
			} catch ( PDOException $e ) {
				$this->plugin->display_admin_error(__('Error:', get_class($this->plugin)) . $e->getMessage());
			}
			return $categories;		
		}
		
		/**
		 * Import K2 items
		 *
		 */
		public function import_items() {
			$step = 1000; // to limit the results
			
			$this->post_type = ($this->plugin->plugin_options['import_as_pages'] == 1) ? 'page' : 'post';
			
			$tab_categories = $this->plugin->tab_categories(); // Get the categories list
			$this->custom_fields = $this->get_custom_fields(); // Get the custom fields
			
			// Hook for doing other actions before the import
			do_action('fgj2wp_k2_pre_import_items');
			
			do {
				$items = $this->get_items($step); // Get the K2 items
				
				if ( is_array($items) ) {
					foreach ( $items as $item ) {
						
						// Hook for modifying the K2 item before processing
						$item = apply_filters('fgj2wp_k2_pre_process_item', $item);
						
						// Medias
						if ( !$this->plugin->plugin_options['skip_media'] ) {
							
							// K2 featured image
							$img_featured_image = '';
							$featured_image = $this->get_featured_image($item['id']);
							if ( $featured_image ) {
								// Caption
								$caption_att = '';
								if ( !empty($item['image_caption']) ) {
									$caption_att = ' class="caption" title="' . $item['image_caption'] . '"';
								}
								$img_featured_image = sprintf('<img src="%s" alt="%s"%s />', $featured_image, $item['image_credits'], $caption_att);
								if ( $this->k2_options['k2_images'] == 'in_content' ) {
									$item['introtext'] = $img_featured_image . $item['introtext'];
								}
							}
							
							// Attachments
							$attachments_links = $this->build_attachment_links($item['id']);
							if ( !empty($item['fulltext']) ) {
								$item['fulltext'] .= $attachments_links;
							} else {
								$item['introtext'] .= $attachments_links;
							}
							
							// Import media
							$result = $this->plugin->import_media($img_featured_image . $item['introtext'] . $item['fulltext'], $item['date']);
							$item_media = $result['media'];
							$this->media_count += $result['media_count'];
							
							// K2 Video
							$video_content = $this->build_video_content($item);
							if ( !empty($item['fulltext']) ) {
								$item['fulltext'] .= $video_content;
							} else {
								$item['introtext'] .= $video_content;
							}
							
							// K2 image gallery
							$gallery_content = $this->build_gallery_content($item);
							if ( !empty($item['fulltext']) ) {
								$item['fulltext'] .= $gallery_content;
							} else {
								$item['introtext'] .= $gallery_content;
							}
							
							
						} else {
							// Skip media
							$item_media = array();
						}
						
						// Category ID
						$category = sanitize_title($item['category']);
						if ( array_key_exists($category, $tab_categories) ) {
							$cat_id = $tab_categories[$category];
						} else {
							$cat_id = 1; // default category
						}
						
						// Define excerpt and post content
						list($excerpt, $content) = $this->plugin->set_excerpt_content($item);
						
						// Process content
						$excerpt = $this->plugin->process_content($excerpt, $item_media);
						$content = $this->plugin->process_content($content, $item_media);
						
						// Status
						$status = ($item['state'] == 1)? 'publish' : 'draft';
						
						// Tags
						$tags = $this->get_tags($item['id']);
						$this->tags_count += count($tags);
						
						// Insert the post
						$new_post = array(
							'post_category'		=> array($cat_id),
							'post_content'		=> $content,
							'post_date'			=> $item['date'],
							'post_excerpt'		=> $excerpt,
							'post_status'		=> $status,
							'post_title'		=> $item['title'],
							'post_name'			=> $item['alias'],
							'post_type'			=> $this->post_type,
							'tags_input'		=> $tags,
							'menu_order'        => $item['ordering'],
						);
						
						// Hook for modifying the WordPress post just before the insert
						$new_post = apply_filters('fgj2wp_k2_pre_insert_post', $new_post, $item);
						
						$new_post_id = wp_insert_post($new_post);
						if ( $new_post_id ) { 
							// Add links between the post and its medias
							$this->plugin->add_post_media($new_post_id, $new_post, $item_media, !empty($featured_image) || $this->plugin->plugin_options['first_image'] != 'as_is');
							
							// Add the K2 ID as a post meta in order to modify links and to import comments
							add_post_meta($new_post_id, '_fgj2wp_old_k2_id', $item['id'], true);
							
							// Add the custom fields
							$this->import_custom_fields($new_post_id, $item['extra_fields']);
							
							// Increment the Joomla last imported post ID
							update_option('fgj2wp_last_k2_item_id', $item['id']);

							$this->items_count++;
							
							// Hook for doing other actions after inserting the post
							do_action('fgj2wp_k2_post_insert_post', $new_post_id, $item);
						}
					}
				}
			} while ( ($items != null) && (count($items) > 0) );
		}
		
		/**
		 * Save the K2 options
		 *
		 */
		public function save_k2_options() {
			$this->k2_options = array_merge($this->k2_options, $this->validate_form_info());
			update_option('fgj2wpk2_options', $this->k2_options);
		}
		
		/**
		 * Validate POST info
		 *
		 * @return array Form parameters
		 */
		private function validate_form_info() {
			return array(
				'k2_images'				=> !empty($_POST['k2_images'])? $_POST['k2_images']: 'in_content',
				'keep_k2_id'			=> !empty($_POST['keep_k2_id']),
			);
		}
		
		/**
		 * Get K2 items
		 *
		 * @param int limit Number of items max
		 * @return array of Items
		 */
		protected function get_items($limit=1000) {
			global $joomla_db;
			$items = array();
			
			$last_id = (int)get_option('fgj2wp_last_k2_item_id'); // to restore the import where it left

			try {
				$prefix = $this->plugin->plugin_options['prefix'];
				
				// Hooks for adding extra cols and extra joins
				$extra_cols = apply_filters('fgj2wp_k2_get_items_add_extra_cols', '');
				$extra_joins = apply_filters('fgj2wp_k2_get_items_add_extra_joins', '');
				
				$sql = "
					SELECT p.id, p.title, p.alias, p.introtext, p.fulltext, p.video, p.video_caption, p.video_credits, p.gallery, p.published AS state, CONCAT('ck', c.id, '-', c.alias) AS category, p.modified, p.created AS `date`, p.metakey, p.metadesc, p.ordering, p.image_caption, p.image_credits,
					p.extra_fields, p.created_by, p.created_by_alias
					$extra_cols
					FROM ${prefix}k2_items p
					LEFT JOIN ${prefix}k2_categories AS c ON p.catid = c.id
					$extra_joins
					WHERE p.published >= 0 -- don't get the trash
					AND p.trash = 0
					AND p.id > '$last_id'
					ORDER BY p.id
					LIMIT $limit
				";
				
				$query = $joomla_db->query($sql);
				if ( is_object($query) ) {
					foreach ( $query as $row ) {
						$items[] = $row;
					}
				}
			} catch ( PDOException $e ) {
				$this->plugin->display_admin_error(__('Error:', get_class($this->plugin)) . $e->getMessage());
			}
			return $items;		
		}

		/**
		 * Display the number of imported items
		 * 
		 */
		public function display_items_count() {
			$this->plugin->display_admin_notice(sprintf(_n('%d K2 item imported', '%d K2 items imported', $this->items_count, __CLASS__), $this->items_count));
		}

		/**
		 * Get the featured images
		 * 
		 * @param int $item_id Item ID
		 * @return string Image name
		 */
		private function get_featured_image($item_id) {
			$image_name = '/media/k2/items/src/' . md5("Image".$item_id) . '.jpg';
			$image_url = $this->plugin->plugin_options['url'] . $image_name;
			if ( $this->url_exists($image_url) ) {
				return $image_name;
			} else {
				return '';
			}
		}
		
		/**
		 * Get the images in the gallery
		 * 
		 * @param int $item_id Item ID
		 * @return array Images names
		 */
		private function get_gallery_images($item_id) {
			$images = array();
			$gallery_dir = '/media/k2/galleries/' . $item_id;
			$item_url = $this->plugin->plugin_options['url'] . '/index.php?option=com_k2&view=item&id=' . $item_id;
			
			// Read the K2 item
			$response = wp_remote_get($item_url); // Uses WordPress HTTP API

			// Check for the images in the gallery
			if ( is_array($response) && !empty($response['body']) ) {
				if ( preg_match_all("#($gallery_dir/.*?)\"#", $response['body'], $matches) ) {
					$images = $matches[1];
				}
			}
			return $images;
		}
		
		/**
		 * Test if a file exists
		 * 
		 * @param string $filePath
		 * @return boolean True if the file exists
		 */
		public function url_exists($filePath) {
			$filePath = str_replace(' ', '%20', $filePath);
			$headers = @get_headers($filePath);
			return preg_match("|200|", $headers[0]);
		}
		
		/**
		 * Get the K2 tags of an item
		 * 
		 * @param int $item_id
		 * @return array Array of tags
		 */
		private function get_tags($item_id) {
			global $joomla_db;
			
			$tags = array();
			try {
				$prefix = $this->plugin->plugin_options['prefix'];
				
				$sql = "
					SELECT t.name
					FROM ${prefix}k2_tags_xref AS x
					INNER JOIN ${prefix}k2_tags AS t ON t.id = x.tagID AND t.published = 1
					WHERE x.itemID = '$item_id'
				";
				
				$query = $joomla_db->query($sql);
				if ( is_object($query) ) {
					foreach ( $query as $row ) {
						$tags[] = $row['name'];
					}
				}
			} catch ( PDOException $e ) {
				$this->plugin->display_admin_error(__('Error:', get_class($this->plugin)) . $e->getMessage());
			}
			return $tags;
		}
		
		/**
		 * Display the number of imported tags
		 * 
		 */
		public function display_tags_count() {
			$this->plugin->display_admin_notice(sprintf(_n('%d K2 tag imported', '%d K2 tags imported', $this->tags_count, __CLASS__), $this->tags_count));
		}

		/**
		 * Import the K2 comments
		 * 
		 * @param int $new_post_id New post ID
		 * @param array $item K2 item
		 */
		public function import_comments($new_post_id, $item) {
			$comments = $this->get_comments($item['id']);
			foreach ( $comments as $comment ) {
				$data = array(
					'comment_post_ID' => $new_post_id,
					'comment_author' => $comment['userName'],
					'comment_author_email' => $comment['commentEmail'],
					'comment_author_url' => $comment['commentURL'],
					'comment_content' => $comment['commentText'],
					'comment_type' => '',
					'comment_parent' => 0,
					'comment_date' => $comment['commentDate'],
					'comment_approved' => $comment['published'],
				);
				wp_insert_comment($data);
				$this->comments_count++;
			}
		}

		/**
		 * Get the K2 comments of an item
		 * 
		 * @param int $item_id
		 * @return array Array of comments
		 */
		private function get_comments($item_id) {
			global $joomla_db;
			
			$comments = array();
			try {
				
				$prefix = $this->plugin->plugin_options['prefix'];
				
				$sql = "
					SELECT c.userID, c.userName, c.commentDate, c.commentText, c.commentEmail, c.commentURL, c.published
					FROM ${prefix}k2_comments AS c
					WHERE c.itemID = '$item_id'
				";
				
				$query = $joomla_db->query($sql);
				if ( is_object($query) ) {
					foreach ( $query as $row ) {
						$comments[] = $row;
					}
				}
			} catch ( PDOException $e ) {
				$this->plugin->display_admin_error(__('Error:', get_class($this->plugin)) . $e->getMessage());
			}
			return $comments;
		}

		/**
		 * Display the number of imported comments
		 * 
		 */
		public function display_comments_count() {
			$this->plugin->display_admin_notice(sprintf(_n('%d K2 comment imported', '%d K2 comments imported', $this->comments_count, __CLASS__), $this->comments_count));
		}

		/**
		 * Build the K2 attachments links
		 * 
		 * @param int $item_id
		 * @return string attachment links
		 */
		public function build_attachment_links($item_id) {
			$attachment_link = '';
			$attachments = $this->get_attachments($item_id);
			foreach ( $attachments as $attachment ) {
				$attachment_name = '/media/k2/attachments/' . $attachment['filename'];
				$attachment_url = $this->plugin->plugin_options['url'] . $attachment_name;
				if ( $this->url_exists($attachment_url) ) {
					$attachment_link .= "<br />\n" . '<a href="' . $attachment_url . '" alt="' . $attachment['titleAttribute'] . '">' . $attachment['title'] . '</a>';
				}
			}
			return $attachment_link;
		}

		/**
		 * Get the K2 attachments of an item
		 * 
		 * @param int $item_id
		 * @return array Array of attachments
		 */
		private function get_attachments($item_id) {
			global $joomla_db;
			
			$attachments = array();
			try {
				$prefix = $this->plugin->plugin_options['prefix'];
				
				$sql = "
					SELECT a.filename, a.title, a.titleAttribute
					FROM ${prefix}k2_attachments AS a
					WHERE a.itemID = '$item_id'
				";
				
				$query = $joomla_db->query($sql);
				if ( is_object($query) ) {
					foreach ( $query as $row ) {
						$attachments[] = $row;
					}
				}
			} catch ( PDOException $e ) {
				$this->plugin->display_admin_error(__('Error:', get_class($this->plugin)) . $e->getMessage());
			}
			return $attachments;
		}
		
		/**
		 * Build the video content from the K2 video fields
		 * 
		 * @param array $item K2 item
		 * @return string Video content
		 */
		private function build_video_content($item) {
			$video_content = '';
			if ( !empty($item['video']) ) {
				$video_content .= "<div class=\"k2_video\">";
				
				// Video caption
				if ( !empty($item['video_caption']) ) {
					$video_content .= "<div class=\"k2_video_caption\">" . $item['video_caption'] . "</div>\n";
				}
				
				// Embedded video
				// Replace the iframe tag by a shortcode because WordPress removes it if we are not a super-admin
				// We can use the plugin http://wordpress.org/extend/plugins/iframe/ to view the iframe
				$video_content .= preg_replace("#<iframe(.*?)></iframe>#", "[iframe$1]", $item['video']);
				
				// Video credits
				if ( !empty($item['video_credits']) ) {
					$video_content .= "<div class=\"k2_video_credits\">" . $item['video_credits'] . "</div>\n";
				}
				$video_content .= "</div>\n";
			}
			return $video_content;
		}
		
		/**
		 * Build the gallery content from the K2 gallery field
		 * 
		 * @param array $item K2 item
		 * @return string Gallery content
		 */
		private function build_gallery_content($item) {
			$gallery_content = '';
			if ( !empty($item['gallery']) ) {
				$images_ids = array();
				$images = $this->get_gallery_images($item['id']);
				$images_string = '';
				foreach ( $images as $image ) {
					$image_url = $this->plugin->plugin_options['url'] . $image;
					$images_string .= '<img src="' . $image_url . '" /> ';
				}
				
				// Import the images
				$result = $this->plugin->import_media($images_string, $item['date']);
				$this->media_count += $result['media_count'];
				foreach ( $result['media'] as $media ) {
					$images_ids[] = $media['id'];
				}
				
				// Create gallery shortcode
				if ( !empty($images_ids) ) {
					$gallery_content = '[gallery ids="' .  implode(',', $images_ids) . '"]';
				}
			}
			return $gallery_content;
		}
		
		/**
		 * Display the number of imported media
		 * 
		 */
		public function display_media_count() {
			$this->plugin->display_admin_notice(sprintf(_n('%d K2 media imported', '%d K2 media imported', $this->media_count, __CLASS__), $this->media_count));
		}

		/**
		 * Get the K2 custom fields
		 * 
		 */
		private function get_custom_fields() {
			global $joomla_db;
			
			$custom_fields = array();
			try {
				$prefix = $this->plugin->plugin_options['prefix'];
				
				$sql = "
					SELECT ef.id, ef.name, ef.value
					FROM ${prefix}k2_extra_fields AS ef
					WHERE ef.published = 1
					ORDER BY ef.ordering
				";
				
				$query = $joomla_db->query($sql);
				if ( is_object($query) ) {
					foreach ( $query as $row ) {
						$options = json_decode($row['value']);
						$values = array();
						foreach ( $options as $option ) {
							if ( !empty($option->value) ) {
								$values[$option->value] = $option->name;
							}
						}
						$custom_fields[$row['id']] = (object) array(
							'name'	=> $row['name'],
							'value'	=> $values,
						);
					}
				}
			} catch ( PDOException $e ) {
				$this->plugin->display_admin_error(__('Error:', get_class($this->plugin)) . $e->getMessage());
			}
			return $custom_fields;
		}
		
		/**
		 * Import the extra fields for the current post
		 *
		 * @param int $new_post_id WordPress post ID
		 * @param string $json_extra_fields Extra field in JSON
		 */
		private function import_custom_fields($new_post_id, $json_extra_fields) {
			$extra_fields = json_decode($json_extra_fields);
			if ( is_array($extra_fields) ) {
				foreach ( $extra_fields as $extra_field ) {
					$custom_field = $this->custom_fields[$extra_field->id];
					if ( empty($custom_field->value) ) {
						// text value
						$custom_value = $extra_field->value;
					} else {
						// indexed value
						if ( is_array($extra_field->value) ) {
							// multi-select field
							$custom_values = array();
							foreach ( $extra_field->value as $indexed_value ) {
								$custom_values[] = $custom_field->value[$indexed_value];
							}
							$custom_value = implode( ', ', $custom_values);
						} else {
							// mono-select field
							$custom_value = $custom_field->value[$extra_field->value];
						}
					}
					add_post_meta($new_post_id, $custom_field->name, $custom_value, true);
				}
			}
		}
		
		/**
		 * Get the K2 item ID in a link
		 * Used to modify K2 internal links
		 *
		 * @param array('meta_key' => $meta_key, 'meta_value' => $meta_value) $meta_key_value
		 * @param string $link
		 * @return array('meta_key' => $meta_key, 'meta_value' => $meta_value)
		 */
		public function get_k2_item_id_in_link($meta_key_value, $link) {
			if ( $meta_key_value['meta_value'] != 0 ) {
				return $meta_key_value; // ID already found
			}
			// Without URL rewriting
			if ( preg_match("#view=item&id=(\d+)#", $link, $matches) ) {
				$meta_key_value['meta_key'] = '_fgj2wp_old_k2_id';
				$meta_key_value['meta_value'] = $matches[1];
			}
			// With URL rewriting
			elseif ( preg_match("#(.*)/item/(\d+)-(.*)#", $link, $matches) ) {
				$meta_key_value['meta_key'] = '_fgj2wp_old_k2_id';
				$meta_key_value['meta_value'] = $matches[2];
			}
			return $meta_key_value;
		}
		
		/**
		 * Add the K2 menus in the menu query
		 */
		public function add_menus_extra_criteria($extra_criteria) {
			$sql = "
					OR (type = 'component'
						AND link LIKE '%option=com_k2%'
						AND (link LIKE '%id=%')
						)
			";
			return $extra_criteria . $sql;
		}
		
		/**
		 * Get the menu item data (object_id, type, url, object)
		 * 
		 * @param array $menu Menu item row
		 * @param string $post_type Post type
		 * @return array Menu item
		 */
		public function get_menu_item($menu_item, $menu, $post_type) {
			if ( !is_null($menu_item) ) {
				return $menu_item;
			}
			$menu_item_object_id = 0;
			$menu_item_type = '';
			$menu_item_url = '';
			$menu_item_object = '';
			switch ( $menu['type'] ) {
				case 'component':
					if ( preg_match('/view=item(&.*)?&id=(\d+)/', $menu['link'], $matches) ) {
						// K2 item
						$menu_item_type = 'post_type';
						$menu_item_object = $post_type;
						$posts = get_posts(array(
							'posts_per_page'  => 1,
							'post_type'       => $post_type,
							'meta_key'        => '_fgj2wp_old_k2_id',
							'meta_value'      => $matches[2],
						));
						if ( is_array($posts) && count($posts) > 0 ) {
							$menu_item_object_id = $posts[0]->ID;
						} else return;
						
					} elseif ( preg_match('/view=(itemlist)(&.*)?&id=(\d+)/', $menu['link'], $matches) ) {
						// K2 category
						$menu_item_type = 'taxonomy';
						$menu_item_object = 'category';
						
						$taxonomy = $matches[1];
						$jterm_id = $matches[3];
						if ( ($taxonomy == 'itemlist') && preg_match('/task=category/', $menu['link']) ) {
							$slug_prefix = 'ck'; // K2 category
						} else return;
						$slug_prefix .= $jterm_id . '-';
						$menu_item_object_id = $this->plugin->get_term_id_by_slug("$slug_prefix%");
						if ( empty($menu_item_object_id) ) {
							return;
						}
					} else return;
					break;
				
				default: return;
			}
			
			return array(
				'object_id'	=> $menu_item_object_id,
				'type'		=> $menu_item_type,
				'url'		=> $menu_item_url,
				'object'	=> $menu_item_object,
			);
		}
		
		/**
		 * Remove the filter "keep Joomla IDs" if the "keep K2 IDs" option is set
		 * 
		 */
		public function remove_keep_joomla_id() {
			if ( $this->k2_options['keep_k2_id'] ) {
				remove_filter('fgj2wp_pre_insert_post', array($this->plugin, 'add_import_id'));
			}
		}
		
		/**
		 * Set the posts table autoincrement to the last K2 ID + 100
		 * 
		 */
		public function set_posts_autoincrement() {
			global $wpdb;
			if ( $this->k2_options['keep_k2_id'] ) {
				$last_k2_article_id = $this->get_last_k2_article_id() + 100;
				$sql = "ALTER TABLE $wpdb->posts AUTO_INCREMENT = $last_k2_article_id";
				$wpdb->query($sql);
			}
		}
		
		/**
		 * Get the last K2 article ID
		 *
		 * @return int Last K2 item ID
		 */
		private function get_last_k2_article_id() {
			global $joomla_db;
			$max_id = 0;
			try {
				
				$prefix = $this->plugin->plugin_options['prefix'];
				
				$sql = "
					SELECT max(id) AS max_id
					FROM ${prefix}k2_items
				";
				$query = $joomla_db->query($sql);
				if ( is_object($query) ) {
					foreach ( $query as $row ) {
						$max_id = $row['max_id'];
						break;
					}
				}
			} catch ( PDOException $e ) {
				$this->plugin->display_admin_error(__('Error:', 'fgj2wp') . $e->getMessage());
			}
			return $max_id;		
		}
		
		/**
		 * Keep the K2 ID
		 * 
		 * @param array $newpost New post
		 * @param array $item K2 item
		 * @return array Post
		 */
		public function add_import_id($new_post, $item) {
			if ( $this->k2_options['keep_k2_id'] ) {
				$new_post['import_id'] = $item['id'];
			}
			return $new_post;
		}
		
		/**
		 * Pre_insert_post hook
		 * 
		 * @param array $new_post WordPress post
		 * @param array $item K2 item
		 * @return array WordPress post
		 */
		public function pre_insert_post($new_post, $item) {
			return apply_filters('fgj2wp_pre_insert_post', $new_post, $item);
		}
		
		/**
		 * Post_insert_post hook
		 * 
		 * @param array $new_post_id WordPress post ID
		 * @param array $item K2 item
		 */
		public function post_insert_post($new_post_id, $item) {
			return do_action('fgj2wp_post_insert_post', $new_post_id, $item);
		}
		
		/**
		 * Add information to the admin page
		 * 
		 * @param array $data
		 * @return array
		 */
		public function process_admin_page($data) {
			$data['title'] .= ' ' . __('+ K2 module', __CLASS__);
			$data['description'] .= "<br />" . __('The K2 module will also import K2 content (items, categories, comments, tags, images, videos, attachments and custom fields).', __CLASS__);
			
			$comments_count = wp_count_comments();
			$data['comments_count'] = $comments_count->total_comments;
			$data['database_info'][] = sprintf(_n('%d comment', '%d comments', $data['comments_count'], __CLASS__), $data['comments_count']);
			return $data;
		}
		
		/**
		 * Add K2 options to the admin page
		 * 
		 */
		public function display_k2_options() {
			echo '<tr><th>' . __('K2 images:', __CLASS__) . '</th><td>';
			echo '<input type="radio" name="k2_images" id="k2_images_in_content" value="in_content" ' . checked($this->k2_options['k2_images'], 'in_content', false) . ' /> <label for="k2_images_in_content">' . __('Import the K2 images in the content + as featured images', __CLASS__) . '</label><br />';
			echo '<input type="radio" name="k2_images" id="k2_images_featured" value="featured" ' . checked($this->k2_options['k2_images'], 'featured', false) . ' /> <label for="k2_images_featured">' . __('Import the K2 images as featured images only', __CLASS__) . '</label>';
			echo '</td></tr>';
			
			echo '<tr><th>' . __('K2 SEO:', __CLASS__) . '</th><td>';
			echo '<input type="checkbox" name="keep_k2_id" id="keep_k2_id" value="1" ' . checked($this->k2_options['keep_k2_id'], 1, false) . ' /> <label for="keep_k2_id">' . __('Keep the K2 items IDs. <sub>Note that the Joomla articles IDs won\'t be kept.</sub>', __CLASS__) . '</label><br />';
			echo '</td></tr>';
		}

	}
}
?>
